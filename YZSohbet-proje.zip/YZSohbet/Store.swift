import Foundation
import SwiftUI
import PDFKit
import AVFoundation
import UIKit

// MARK: - Uygulama durumu ve sohbet mantığı

@MainActor
final class Store: ObservableObject {
    @Published var chats: [Chat] = [] {
        didSet { saveChats() }
    }
    @Published var settings: AppSettings {
        didSet { saveSettings() }
    }
    @Published var searchOn: Bool = false {
        didSet { UserDefaults.standard.set(searchOn, forKey: "searchOn") }
    }
    @Published var currentID: UUID? = nil
    @Published var activeRoleID: UUID? = nil
    @Published var preferredID: UUID? = nil
    @Published var busy: Bool = false
    // Canlı akış ayrı nesnede: sadece akan balon yeniden çizilir (hız için)
    let live = StreamState()
    @Published var tab: Int = 0

    private let chatsURL: URL
    private var task: Task<Void, Never>? = nil

    init() {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = dir.appendingPathComponent("chats.json")
        chatsURL = url

        if let d = Keychain.load(account: "settings"),
           let s = try? JSONDecoder().decode(AppSettings.self, from: d) {
            settings = s
        } else {
            settings = AppSettings.defaults()
        }
        if let d = try? Data(contentsOf: url),
           let c = try? JSONDecoder().decode([Chat].self, from: d) {
            chats = c
        }
        searchOn = UserDefaults.standard.bool(forKey: "searchOn")
    }

    // MARK: Hesaplanan değerler

    var currentChat: Chat? {
        return chats.first(where: { $0.id == currentID })
    }

    var roles: [Role] {
        return settings.roles ?? AppSettings.defaultRoles()
    }

    func role(_ id: UUID?) -> Role? {
        guard let id = id else { return nil }
        return roles.first(where: { $0.id == id })
    }

    var currentRole: Role? {
        if let c = currentChat { return role(c.roleID) }
        return role(activeRoleID)
    }

    var accent: Color {
        return themeColor(settings.accent ?? "turuncu")
    }

    var colorScheme: ColorScheme? {
        switch settings.theme ?? "system" {
        case "light": return .light
        case "dark": return .dark
        default: return nil
        }
    }

    // MARK: Kaydetme

    private func saveChats() {
        if let d = try? JSONEncoder().encode(chats) {
            try? d.write(to: chatsURL, options: .atomic)
        }
    }

    private func saveSettings() {
        if let d = try? JSONEncoder().encode(settings) {
            Keychain.save(d, account: "settings")
        }
    }

    // MARK: Sohbet işlemleri

    func newChat() {
        currentID = nil
        tab = 0
    }

    func deleteChat(_ id: UUID) {
        chats.removeAll(where: { $0.id == id })
        if currentID == id { currentID = nil }
    }

    func deleteAllChats() {
        chats = []
        currentID = nil
    }

    func togglePin(_ id: UUID) {
        if let i = chats.firstIndex(where: { $0.id == id }) {
            chats[i].pinned = !(chats[i].pinned ?? false)
        }
    }

    func rename(_ id: UUID, _ title: String) {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return }
        if let i = chats.firstIndex(where: { $0.id == id }) {
            chats[i].title = t
        }
    }

    func transcript(_ c: Chat) -> String {
        var out = c.title + "\n\n"
        for m in c.messages {
            if m.role == "user" { out += "Ben: " + m.content + "\n\n" }
            else if m.role == "assistant" { out += "YZ: " + m.content + "\n\n" }
        }
        return out
    }

    private func append(_ m: ChatMessage, to id: UUID) {
        if let i = chats.firstIndex(where: { $0.id == id }) {
            chats[i].messages.append(m)
            chats[i].updated = Date()
        }
    }

    // MARK: Rol işlemleri

    func saveRole(_ r: Role) {
        var list = roles
        if let i = list.firstIndex(where: { $0.id == r.id }) {
            list[i] = r
        } else {
            list.append(r)
        }
        settings.roles = list
    }

    func deleteRole(_ id: UUID) {
        var list = roles
        list.removeAll(where: { $0.id == id })
        settings.roles = list
        if activeRoleID == id { activeRoleID = nil }
    }

    // Tüm roller silindiyse varsayılanları geri getirir
    func resetRoles() {
        settings.roles = nil
        activeRoleID = nil
    }

    // MARK: Model listesi işlemleri

    func moveEntry(_ id: UUID, by d: Int) {
        guard let i = settings.entries.firstIndex(where: { $0.id == id }) else { return }
        let j = i + d
        if j < 0 || j >= settings.entries.count { return }
        settings.entries.swapAt(i, j)
    }

    func removeEntry(_ id: UUID) {
        settings.entries.removeAll(where: { $0.id == id })
        if preferredID == id { preferredID = nil }
    }

    func addEntry() {
        settings.entries.append(ProviderEntry(name: "Yeni model", type: .openai, baseURL: "https://", model: "", key: "", enabled: true))
    }

    func resetEntries() {
        settings.entries = AppSettings.defaults().entries
        preferredID = nil
    }

    func test(_ e: ProviderEntry) async -> String {
        do {
            let reply = try await APIClient.stream(e,
                                                   [APIMessage(role: "user", text: "Sadece 'tamam' yaz.", images: [])],
                                                   system: "Kısa cevap ver.",
                                                   maxTokens: 30,
                                                   onDelta: { _ in })
            return "✓ Çalışıyor. Cevap: " + reply
        } catch {
            return "✗ Hata: " + error.localizedDescription
        }
    }

    // MARK: Gönderme, durdurma, yeniden oluşturma

    func startSend(_ text: String, _ atts: [Attachment]) {
        if busy { return }
        task = Task { await self.send(text, atts) }
    }

    func startRegenerate() {
        if busy { return }
        task = Task { await self.regenerate() }
    }

    func stop() {
        task?.cancel()
    }

    private func send(_ text: String, _ atts: [Attachment]) async {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty && atts.isEmpty { return }
        let content = trimmed.isEmpty ? "Ekteki dosyaları incele ve kısaca özetle." : trimmed

        let chatID: UUID
        if let c = currentChat {
            chatID = c.id
        } else {
            var c = Chat(title: String(content.prefix(40)))
            c.roleID = activeRoleID
            chats.append(c)
            currentID = c.id
            chatID = c.id
        }
        append(ChatMessage(role: "user", content: content, attachments: atts.isEmpty ? nil : atts), to: chatID)
        await generate(chatID: chatID)
    }

    private func regenerate() async {
        guard let c = currentChat else { return }
        var msgs = c.messages
        while let last = msgs.last, last.role != "user" {
            msgs.removeLast()
        }
        if msgs.isEmpty { return }
        if let i = chats.firstIndex(where: { $0.id == c.id }) {
            chats[i].messages = msgs
        }
        await generate(chatID: c.id)
    }

    private static func apiMessage(_ m: ChatMessage) -> APIMessage {
        var text = m.content
        var images: [String] = []
        for a in m.attachments ?? [] {
            if a.kind == "image", let b = a.imageBase64 {
                images.append(b)
            } else if let t = a.text {
                text += "\n\n[Ek dosya: \(a.name)]\n\(t)\n[Dosya sonu]"
            }
        }
        return APIMessage(role: m.role, text: text, images: images)
    }

    private func buildSystem(role: Role?) -> String {
        var s = "Sen yardımcı bir asistansın. Kullanıcı hangi dilde yazıyorsa o dilde, açık ve anlaşılır cevap ver."
        if let r = role, !r.prompt.isEmpty {
            s += "\n\n" + r.prompt
        }
        let ci = (settings.customInstructions ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !ci.isEmpty {
            s += "\n\n[Kullanıcının özel talimatları]\n" + ci
        }
        return s
    }

    // Otomatik model geçişi burada
    private func generate(chatID: UUID) async {
        var entries = settings.entries.filter {
            $0.enabled && !$0.key.trimmingCharacters(in: .whitespaces).isEmpty
        }
        if entries.isEmpty {
            append(ChatMessage(role: "error", content: "Hiç API anahtarı girilmemiş. Ayarlar sekmesinden en az bir anahtar gir."), to: chatID)
            return
        }
        if let p = preferredID, let i = entries.firstIndex(where: { $0.id == p }) {
            let e = entries.remove(at: i)
            entries.insert(e, at: 0)
        }

        busy = true
        live.text = ""
        defer {
            busy = false
            live.status = ""
            live.text = ""
        }

        guard let chat = chats.first(where: { $0.id == chatID }) else { return }
        var history: [APIMessage] = []
        var lastUserText = ""
        for m in chat.messages where m.role == "user" || m.role == "assistant" {
            history.append(Store.apiMessage(m))
            if m.role == "user" { lastUserText = m.content }
        }
        let system = buildSystem(role: role(chat.roleID))

        if searchOn && !history.isEmpty {
            live.status = "İnternette aranıyor…"
            let ctx = await WebSearch.run(lastUserText, tavilyKey: settings.tavilyKey)
            if !ctx.isEmpty {
                history[history.count - 1].text += "\n\n[İnternet arama sonuçları - gerekirse kullan]\n" + ctx
            }
        }

        var failed: [String] = []
        var errors: [String] = []
        for e in entries {
            live.status = e.name + "…"
            live.text = ""
            let tag = e.name + " · " + e.model
            var latest = ""
            var lastTick = Date.distantPast
            do {
                let reply = try await APIClient.stream(e, history,
                                                       system: system,
                                                       maxTokens: settings.maxTokens ?? 2048,
                                                       onDelta: { [weak self] t in
                                                           latest = t
                                                           let now = Date()
                                                           if now.timeIntervalSince(lastTick) > 0.04 {
                                                               lastTick = now
                                                               self?.live.text = t
                                                           }
                                                       })
                if !failed.isEmpty {
                    append(ChatMessage(role: "note", content: "⚠ Geçildi: " + failed.joined(separator: ", ") + " → " + e.name), to: chatID)
                }
                append(ChatMessage(role: "assistant", content: reply, modelTag: tag), to: chatID)
                return
            } catch {
                let partial = latest
                if Task.isCancelled {
                    if !partial.isEmpty {
                        append(ChatMessage(role: "assistant", content: partial, modelTag: tag + " (durduruldu)"), to: chatID)
                    }
                    return
                }
                if !partial.isEmpty {
                    append(ChatMessage(role: "assistant", content: partial, modelTag: tag), to: chatID)
                    append(ChatMessage(role: "note", content: "⚠ Yanıt yarıda kesildi: " + error.localizedDescription), to: chatID)
                    return
                }
                failed.append(e.name)
                errors.append("• " + e.name + ": " + error.localizedDescription)
            }
        }
        append(ChatMessage(role: "error", content: "Hiçbir model cevap veremedi:\n" + errors.joined(separator: "\n")), to: chatID)
    }
}

// MARK: - Canlı akış durumu

final class StreamState: ObservableObject {
    @Published var text: String = ""
    @Published var status: String = ""
}

// MARK: - API çağrıları (akışlı)

struct APIMessage {
    let role: String
    var text: String
    var images: [String]
}

struct APIError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor
enum APIClient {
    private static func buildRequest(_ e: ProviderEntry, _ msgs: [APIMessage], system: String, maxTokens: Int) throws -> URLRequest {
        var base = e.baseURL.trimmingCharacters(in: .whitespaces)
        while base.hasSuffix("/") { base.removeLast() }

        let path = (e.type == .anthropic) ? "/messages" : "/chat/completions"
        guard let url = URL(string: base + path) else {
            throw APIError(message: "Adres hatalı: " + e.baseURL)
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 60
        req.setValue("application/json", forHTTPHeaderField: "content-type")

        var body: [String: Any]
        if e.type == .anthropic {
            req.setValue(e.key, forHTTPHeaderField: "x-api-key")
            req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            var arr: [[String: Any]] = []
            for m in msgs {
                if m.images.isEmpty {
                    arr.append(["role": m.role, "content": m.text])
                } else {
                    var parts: [[String: Any]] = []
                    for img in m.images {
                        let src: [String: Any] = ["type": "base64", "media_type": "image/jpeg", "data": img]
                        parts.append(["type": "image", "source": src])
                    }
                    parts.append(["type": "text", "text": m.text])
                    arr.append(["role": m.role, "content": parts])
                }
            }
            body = [
                "model": e.model,
                "max_tokens": maxTokens,
                "system": system,
                "messages": arr,
                "stream": true
            ]
        } else {
            req.setValue("Bearer " + e.key, forHTTPHeaderField: "authorization")
            var arr: [[String: Any]] = [["role": "system", "content": system]]
            for m in msgs {
                if m.images.isEmpty {
                    arr.append(["role": m.role, "content": m.text])
                } else {
                    var parts: [[String: Any]] = [["type": "text", "text": m.text]]
                    for img in m.images {
                        let u: [String: Any] = ["url": "data:image/jpeg;base64," + img]
                        parts.append(["type": "image_url", "image_url": u])
                    }
                    arr.append(["role": m.role, "content": parts])
                }
            }
            body = [
                "model": e.model,
                "messages": arr,
                "stream": true
            ]
        }
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        return req
    }

    // Cevabı parça parça alır; onDelta'ya o ana kadarki tüm metni verir
    static func stream(_ e: ProviderEntry, _ msgs: [APIMessage], system: String, maxTokens: Int, onDelta: (String) -> Void) async throws -> String {
        let req = try buildRequest(e, msgs, system: system, maxTokens: maxTokens)
        let (bytes, resp) = try await URLSession.shared.bytes(for: req)

        if let http = resp as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            var data = Data()
            for try await b in bytes {
                data.append(b)
                if data.count > 4000 { break }
            }
            throw errorFrom(http.statusCode, data)
        }

        var total = ""
        for try await line in bytes.lines {
            if !line.hasPrefix("data:") { continue }
            let payload = line.dropFirst(5).trimmingCharacters(in: .whitespaces)
            if payload == "[DONE]" { break }
            guard let d = payload.data(using: .utf8),
                  let j = (try? JSONSerialization.jsonObject(with: d)) as? [String: Any] else { continue }

            var piece = ""
            if e.type == .anthropic {
                let type = j["type"] as? String ?? ""
                if type == "content_block_delta",
                   let delta = j["delta"] as? [String: Any],
                   let t = delta["text"] as? String {
                    piece = t
                } else if type == "error",
                          let er = j["error"] as? [String: Any],
                          let m = er["message"] as? String {
                    throw APIError(message: m)
                }
            } else {
                if let choices = j["choices"] as? [[String: Any]],
                   let first = choices.first,
                   let delta = first["delta"] as? [String: Any],
                   let t = delta["content"] as? String {
                    piece = t
                }
            }
            if !piece.isEmpty {
                total += piece
                onDelta(total)
            }
        }
        if total.isEmpty { throw APIError(message: "Boş cevap geldi") }
        return total
    }

    private static func errorFrom(_ status: Int, _ data: Data) -> APIError {
        var msg = String(data: data, encoding: .utf8) ?? ""
        if let j = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] {
            if let er = j["error"] as? [String: Any], let m = er["message"] as? String {
                msg = m
            } else if let m = j["message"] as? String {
                msg = m
            }
        }
        return APIError(message: "HTTP \(status): \(msg.prefix(300))")
    }
}

// MARK: - İnternet araması

enum WebSearch {
    static func run(_ query: String, tavilyKey: String) async -> String {
        let key = tavilyKey.trimmingCharacters(in: .whitespaces)
        if !key.isEmpty {
            if let r = await tavily(query, key), !r.isEmpty { return r }
        }
        return (await wikipedia(query)) ?? ""
    }

    private static func tavily(_ query: String, _ key: String) async -> String? {
        guard let url = URL(string: "https://api.tavily.com/search") else { return nil }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        req.setValue("Bearer " + key, forHTTPHeaderField: "authorization")
        let body: [String: Any] = ["api_key": key, "query": query, "max_results": 5]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            if let http = resp as? HTTPURLResponse, !(200..<300).contains(http.statusCode) { return nil }
            guard let j = (try JSONSerialization.jsonObject(with: data)) as? [String: Any],
                  let results = j["results"] as? [[String: Any]] else { return nil }
            let lines = results.compactMap { r -> String? in
                guard let t = r["title"] as? String else { return nil }
                let u = r["url"] as? String ?? ""
                let c = r["content"] as? String ?? ""
                return "- \(t) (\(u)): \(c.prefix(400))"
            }
            return lines.joined(separator: "\n")
        } catch {
            return nil
        }
    }

    private static func wikipedia(_ query: String) async -> String? {
        guard var comps = URLComponents(string: "https://tr.wikipedia.org/w/api.php") else { return nil }
        comps.queryItems = [
            URLQueryItem(name: "action", value: "query"),
            URLQueryItem(name: "list", value: "search"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "srlimit", value: "4"),
            URLQueryItem(name: "srsearch", value: query)
        ]
        guard let url = comps.url else { return nil }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let j = (try JSONSerialization.jsonObject(with: data)) as? [String: Any],
                  let qd = j["query"] as? [String: Any],
                  let arr = qd["search"] as? [[String: Any]] else { return nil }
            let lines = arr.compactMap { item -> String? in
                guard let t = item["title"] as? String else { return nil }
                let raw = item["snippet"] as? String ?? ""
                let s = raw.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                return "- \(t): \(s)"
            }
            return lines.joined(separator: "\n")
        } catch {
            return nil
        }
    }
}

// MARK: - Dosya okuma

enum ImageTools {
    // Resmi küçültüp JPEG yapar (API'ye göndermek için)
    static func jpegBase64(_ data: Data, maxSide: CGFloat = 1280) -> String? {
        guard let img = UIImage(data: data) else { return nil }
        let size = img.size
        if size.width <= 0 || size.height <= 0 { return nil }
        let scale = min(1, maxSide / max(size.width, size.height))
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        let renderer = UIGraphicsImageRenderer(size: newSize, format: fmt)
        let resized = renderer.image { _ in
            UIColor.white.setFill()
            UIRectFill(CGRect(origin: .zero, size: newSize))
            img.draw(in: CGRect(origin: .zero, size: newSize))
        }
        return resized.jpegData(compressionQuality: 0.7)?.base64EncodedString()
    }
}

enum ImageCache {
    private static let cache = NSCache<NSString, UIImage>()

    static func image(for a: Attachment) -> UIImage? {
        let key = a.id.uuidString as NSString
        if let i = cache.object(forKey: key) { return i }
        guard let b = a.imageBase64,
              let d = Data(base64Encoded: b),
              let img = UIImage(data: d) else { return nil }
        cache.setObject(img, forKey: key)
        return img
    }
}

enum FileReader {
    static let maxChars = 30000

    static func read(_ url: URL) throws -> Attachment {
        let started = url.startAccessingSecurityScopedResource()
        defer { if started { url.stopAccessingSecurityScopedResource() } }

        let ext = url.pathExtension.lowercased()
        let name = url.lastPathComponent
        let data = try Data(contentsOf: url)

        if ["png", "jpg", "jpeg", "heic", "gif", "webp"].contains(ext) {
            guard let b64 = ImageTools.jpegBase64(data) else {
                throw APIError(message: "\(name) resmi okunamadı.")
            }
            return Attachment(name: name, kind: "image", imageBase64: b64)
        }

        if ext == "pdf" {
            guard let doc = PDFDocument(data: data) else {
                throw APIError(message: "\(name) PDF'i açılamadı.")
            }
            let t = doc.string ?? ""
            if t.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                throw APIError(message: "\(name) içinden yazı çıkarılamadı. Taranmış (resim) PDF olabilir; sayfaları fotoğraf olarak eklemeyi dene.")
            }
            return Attachment(name: name, kind: "text", text: limit(t))
        }

        if ["docx", "xlsx", "pptx", "doc", "xls", "ppt", "zip", "rar"].contains(ext) {
            throw APIError(message: "\(name): .\(ext) dosyaları henüz desteklenmiyor. İçeriği kopyalayıp yapıştırabilir ya da PDF olarak kaydedip ekleyebilirsin.")
        }

        if let s = String(data: data, encoding: .utf8) {
            return Attachment(name: name, kind: "text", text: limit(s))
        }
        throw APIError(message: "\(name) dosya türü okunamadı. Desteklenenler: yazı/kod dosyaları, PDF ve resimler.")
    }

    private static func limit(_ s: String) -> String {
        if s.count <= maxChars { return s }
        return String(s.prefix(maxChars)) + "\n[... dosya uzun olduğu için burada kesildi ...]"
    }
}

// MARK: - Sesli okuma

final class Speaker {
    static let shared = Speaker()
    private let synth = AVSpeechSynthesizer()

    func toggle(_ text: String) {
        if synth.isSpeaking {
            synth.stopSpeaking(at: .immediate)
            return
        }
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        let u = AVSpeechUtterance(string: text)
        u.voice = AVSpeechSynthesisVoice(language: "tr-TR")
        synth.speak(u)
    }
}