import SwiftUI
import PhotosUI
import UIKit
import UniformTypeIdentifiers

// MARK: - Yardımcılar

func markdownText(_ s: String) -> AttributedString {
    let opts = AttributedString.MarkdownParsingOptions(interpretedSyntax: .inlineOnlyPreservingWhitespace)
    if let a = try? AttributedString(markdown: s, options: opts) {
        return a
    }
    return AttributedString(s)
}

private struct Suggestion: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let prompt: String
    let web: Bool
}

// MARK: - Sohbet ekranı

struct ChatView: View {
    @EnvironmentObject var store: Store
    @State private var input = ""
    @State private var pending: [Attachment] = []
    @State private var showImporter = false
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var fileError: String? = nil
    @FocusState private var inputFocused: Bool

    private let suggestions: [Suggestion] = [
        Suggestion(icon: "doc.text", title: "PDF özetle", prompt: "Bu PDF'i özetle", web: false),
        Suggestion(icon: "envelope", title: "E-posta yaz", prompt: "Bir e-posta taslağı yaz", web: false),
        Suggestion(icon: "chevron.left.forwardslash.chevron.right", title: "Kod sor", prompt: "Python'da liste nasıl sıralanır?", web: false),
        Suggestion(icon: "globe", title: "Güncel haberler", prompt: "Bugünün önemli haberleri neler?", web: true)
    ]

    private var messages: [ChatMessage] {
        return store.currentChat?.messages ?? []
    }

    private var canSend: Bool {
        let hasText = !input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        return (hasText || !pending.isEmpty) && !store.busy
    }

    private var showRegenerate: Bool {
        if store.busy { return false }
        guard let last = messages.last else { return false }
        return last.role == "assistant" || last.role == "error"
    }

    private var activeModelName: String {
        if let p = store.preferredID,
           let e = store.settings.entries.first(where: { $0.id == p }) {
            return e.name
        }
        return "Otomatik model"
    }

    private var subtitle: String {
        if let r = store.currentRole {
            return "\(r.emoji) \(r.name) · \(activeModelName)"
        }
        return activeModelName
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        if messages.isEmpty && !store.busy {
                            emptyState
                        }
                        LazyVStack(spacing: 14) {
                            ForEach(messages) { m in
                                Bubble(m: m).id(m.id)
                            }
                            if store.busy {
                                StreamingBubble(live: store.live, onGrow: { proxy.scrollTo("typing", anchor: .bottom) })
                                    .id("typing")
                            }
                            if showRegenerate {
                                regenerateButton.id("regen")
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 12)
                    }
                    .scrollDismissesKeyboard(.interactively)
                    .onChange(of: messages.count) { _ in scrollToEnd(proxy) }
                    .onChange(of: store.busy) { _ in scrollToEnd(proxy) }
                    .onChange(of: store.currentID) { _ in scrollToEnd(proxy, animated: false) }
                }
                composer
            }
            .background(Color(.systemBackground))
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Picker("Model", selection: $store.preferredID) {
                            Text("Otomatik (listedeki sıra)").tag(UUID?.none)
                            ForEach(store.settings.entries) { e in
                                Text(e.name).tag(Optional(e.id))
                            }
                        }
                    } label: {
                        Image(systemName: "cpu")
                    }
                    .accessibilityLabel("Model seç")
                }
                ToolbarItem(placement: .principal) {
                    VStack(spacing: 1) {
                        Text(store.currentChat?.title ?? "Yeni sohbet")
                            .font(.headline)
                            .lineLimit(1)
                        Text(subtitle)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    if let c = store.currentChat {
                        ShareLink(item: store.transcript(c)) {
                            Image(systemName: "square.and.arrow.up")
                        }
                    }
                    Button {
                        Haptics.tap()
                        store.newChat()
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                    .accessibilityLabel("Yeni sohbet")
                }
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
            handleFiles(result)
        }
        .onChange(of: photoItems) { items in
            if items.isEmpty { return }
            Task { await loadPhotos(items) }
        }
        .alert("Dosya eklenemedi",
               isPresented: Binding(get: { fileError != nil }, set: { if !$0 { fileError = nil } })) {
            Button("Tamam", role: .cancel) {}
        } message: {
            Text(fileError ?? "")
        }
    }

    // MARK: Parçalar

    private var emptyState: some View {
        VStack(spacing: 18) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [store.accent, store.accent.opacity(0.55)],
                                         startPoint: .topLeading,
                                         endPoint: .bottomTrailing))
                    .frame(width: 72, height: 72)
                Image(systemName: "sparkles")
                    .font(.system(size: 32, weight: .semibold))
                    .foregroundColor(.white)
            }
            .shadow(color: store.accent.opacity(0.35), radius: 16, x: 0, y: 8)

            VStack(spacing: 4) {
                Text("Merhaba! Ne yapmak istersin?")
                    .font(.title2.bold())
                    .multilineTextAlignment(.center)
                Text("Bir şey sor, dosya ekle ya da aşağıdan bir öneri seç.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }

            if let r = store.currentRole {
                HStack(spacing: 6) {
                    Text("\(r.emoji) \(r.name)")
                        .font(.footnote.weight(.medium))
                    Button {
                        store.activeRoleID = nil
                    } label: {
                        Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
                    }
                    .accessibilityLabel("Rolü kaldır")
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(store.accent.opacity(0.12))
                .clipShape(Capsule())
            }

            let hasKey = store.settings.entries.contains(where: { $0.enabled && !$0.key.isEmpty })
            if !hasKey {
                Button {
                    store.tab = 3
                } label: {
                    Label("Başlamak için API anahtarı ekle", systemImage: "key.fill")
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(store.accent)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                }
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(suggestions) { s in
                    Button {
                        Haptics.tap()
                        input = s.prompt
                        if s.web { store.searchOn = true }
                        inputFocused = true
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            Image(systemName: s.icon)
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(store.accent)
                            Text(s.title)
                                .font(.subheadline.weight(.semibold))
                                .foregroundColor(.primary)
                            Text(s.prompt)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(2)
                                .multilineTextAlignment(.leading)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(.top, 36)
        .padding(.horizontal, 18)
    }

    private var regenerateButton: some View {
        Button {
            Haptics.tap()
            store.startRegenerate()
        } label: {
            Label("Yeniden oluştur", systemImage: "arrow.clockwise")
                .font(.footnote.weight(.medium))
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(Color(.secondarySystemBackground))
                .clipShape(Capsule())
        }
    }

    private func toolIcon(_ name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 18))
            .foregroundColor(.secondary)
            .frame(width: 34, height: 34)
            .contentShape(Rectangle())
    }

    private var webToggle: some View {
        Button {
            Haptics.tap()
            store.searchOn.toggle()
        } label: {
            HStack(spacing: 4) {
                Image(systemName: "globe")
                    .font(.system(size: 16))
                if store.searchOn {
                    Text("İnternet")
                        .font(.caption.weight(.medium))
                }
            }
            .padding(.horizontal, 10)
            .frame(height: 30)
            .background(store.searchOn ? store.accent.opacity(0.15) : Color.clear)
            .foregroundColor(store.searchOn ? store.accent : Color.secondary)
            .clipShape(Capsule())
        }
        .accessibilityLabel("İnternet araması")
    }

    @ViewBuilder
    private var sendButton: some View {
        if store.busy {
            Button {
                store.stop()
            } label: {
                Image(systemName: "stop.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 34, height: 34)
                    .background(store.accent)
                    .clipShape(Circle())
            }
            .accessibilityLabel("Durdur")
        } else {
            Button {
                send()
            } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 34, height: 34)
                    .background(canSend ? store.accent : Color(.systemGray3))
                    .clipShape(Circle())
            }
            .disabled(!canSend)
            .accessibilityLabel("Gönder")
        }
    }

    private var composer: some View {
        VStack(spacing: 8) {
            if !pending.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(pending) { a in
                            AttachmentChip(a: a, removable: true) {
                                pending.removeAll(where: { $0.id == a.id })
                            }
                        }
                    }
                    .padding(.horizontal, 2)
                }
            }

            VStack(spacing: 6) {
                TextField("Bir şey sor…", text: $input, axis: .vertical)
                    .lineLimit(1...6)
                    .focused($inputFocused)
                    .padding(.horizontal, 6)
                    .padding(.top, 4)

                HStack(spacing: 4) {
                    Button {
                        showImporter = true
                    } label: {
                        toolIcon("paperclip")
                    }
                    .accessibilityLabel("Dosya ekle")

                    PhotosPicker(selection: $photoItems, maxSelectionCount: 4, matching: .images) {
                        toolIcon("photo")
                    }
                    .accessibilityLabel("Fotoğraf ekle")

                    webToggle
                    Spacer()
                    sendButton
                }
            }
            .padding(10)
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemBackground))
    }

    // MARK: İşlemler

    private func send() {
        let t = input
        let a = pending
        input = ""
        pending = []
        Haptics.tap()
        store.startSend(t, a)
    }

    private func scrollToEnd(_ proxy: ScrollViewProxy, animated: Bool = true) {
        let go = {
            if store.busy {
                proxy.scrollTo("typing", anchor: .bottom)
            } else if showRegenerate {
                proxy.scrollTo("regen", anchor: .bottom)
            } else if let last = messages.last {
                proxy.scrollTo(last.id, anchor: .bottom)
            }
        }
        if animated {
            withAnimation(.easeOut(duration: 0.25)) { go() }
        } else {
            go()
        }
    }

    private func handleFiles(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            for u in urls {
                do {
                    pending.append(try FileReader.read(u))
                } catch {
                    fileError = error.localizedDescription
                }
            }
        case .failure(let e):
            fileError = e.localizedDescription
        }
    }

    private func loadPhotos(_ items: [PhotosPickerItem]) async {
        for (i, item) in items.enumerated() {
            if let data = try? await item.loadTransferable(type: Data.self),
               let b64 = ImageTools.jpegBase64(data) {
                pending.append(Attachment(name: "Fotoğraf \(i + 1)", kind: "image", imageBase64: b64))
            } else {
                fileError = "Fotoğraf okunamadı."
            }
        }
        photoItems = []
    }
}

// MARK: - Ek dosya etiketi

struct AttachmentChip: View {
    let a: Attachment
    var removable: Bool = false
    var onRemove: () -> Void = {}

    private var iconName: String {
        return a.name.lowercased().hasSuffix(".pdf") ? "doc.richtext" : "doc.text"
    }

    var body: some View {
        HStack(spacing: 6) {
            if a.kind == "image", let img = ImageCache.image(for: a) {
                Image(uiImage: img)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 36, height: 36)
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            } else {
                Image(systemName: iconName)
                    .foregroundColor(.secondary)
            }
            Text(a.name)
                .font(.caption)
                .lineLimit(1)
                .frame(maxWidth: 140, alignment: .leading)
            if removable {
                Button { onRemove() } label: {
                    Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
                }
                .accessibilityLabel("Eki kaldır")
            }
        }
        .padding(6)
        .background(Color(.tertiarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

// MARK: - Mesaj balonu

struct Bubble: View {
    @EnvironmentObject var store: Store
    let m: ChatMessage

    var body: some View {
        switch m.role {
        case "user":
            userBubble
        case "note":
            Text(m.content)
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color(.secondarySystemBackground))
                .clipShape(Capsule())
                .frame(maxWidth: .infinity)
        case "error":
            errorBubble
        default:
            assistantBubble
        }
    }

    private var userBubble: some View {
        HStack {
            Spacer(minLength: 48)
            VStack(alignment: .trailing, spacing: 6) {
                if let atts = m.attachments, !atts.isEmpty {
                    ForEach(atts) { a in
                        AttachmentChip(a: a)
                    }
                }
                Text(m.content)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(store.accent)
                    .foregroundColor(.white)
                    .roundedCorners(18, [.topLeft, .topRight, .bottomLeft])
                    .textSelection(.enabled)
            }
        }
    }

    private var errorBubble: some View {
        HStack {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.red)
                Text(m.content)
                    .font(.footnote)
                    .textSelection(.enabled)
            }
            .padding(12)
            .background(Color.red.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            Spacer(minLength: 20)
        }
    }

    private var assistantBubble: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                MarkdownView(text: m.content)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color(.secondarySystemBackground))
                    .roundedCorners(18, [.topRight, .bottomLeft, .bottomRight])
                Spacer(minLength: 24)
            }
            HStack(spacing: 16) {
                CopyButton(text: m.content)
                Button {
                    Haptics.tap()
                    Speaker.shared.toggle(m.content)
                } label: {
                    Image(systemName: "speaker.wave.2")
                }
                .accessibilityLabel("Sesli oku")
                ShareLink(item: m.content) {
                    Image(systemName: "square.and.arrow.up")
                }
                if let t = m.modelTag {
                    Text(t)
                        .font(.caption2)
                        .lineLimit(1)
                }
            }
            .font(.footnote)
            .foregroundColor(.secondary)
            .padding(.leading, 4)
        }
    }
}

// MARK: - Markdown ve kod blokları

enum MarkdownBlock {
    case paragraph(String)
    case heading(Int, String)
    case bullet(Int, String)
    case numbered(String, String)
    case quote(String)
    case code(String, String)
    case rule
}

enum MarkdownParser {
    static func parse(_ text: String) -> [MarkdownBlock] {
        var blocks: [MarkdownBlock] = []
        var para: [String] = []
        var code: [String] = []
        var lang = ""
        var inCode = false

        func flushPara() {
            if !para.isEmpty {
                blocks.append(.paragraph(para.joined(separator: "\n")))
                para = []
            }
        }

        for raw in text.components(separatedBy: "\n") {
            let trimmed = raw.trimmingCharacters(in: .whitespaces)

            if trimmed.hasPrefix("```") {
                if inCode {
                    blocks.append(.code(lang, code.joined(separator: "\n")))
                    code = []
                    lang = ""
                    inCode = false
                } else {
                    flushPara()
                    lang = String(trimmed.dropFirst(3)).trimmingCharacters(in: .whitespaces)
                    inCode = true
                }
                continue
            }
            if inCode {
                code.append(raw)
                continue
            }
            if trimmed.isEmpty {
                flushPara()
                continue
            }
            if trimmed == "---" || trimmed == "***" || trimmed == "___" {
                flushPara()
                blocks.append(.rule)
                continue
            }
            if let h = heading(trimmed) {
                flushPara()
                blocks.append(h)
                continue
            }
            if trimmed.hasPrefix("> ") {
                flushPara()
                blocks.append(.quote(String(trimmed.dropFirst(2))))
                continue
            }
            if let b = bullet(raw) {
                flushPara()
                blocks.append(b)
                continue
            }
            if let n = numbered(raw) {
                flushPara()
                blocks.append(n)
                continue
            }
            para.append(trimmed)
        }

        if inCode {
            blocks.append(.code(lang, code.joined(separator: "\n")))
        }
        flushPara()
        return blocks
    }

    private static func heading(_ s: String) -> MarkdownBlock? {
        var level = 0
        for ch in s {
            if ch == "#" { level += 1 } else { break }
        }
        if level < 1 || level > 6 { return nil }
        let rest = String(s.dropFirst(level))
        if !rest.hasPrefix(" ") { return nil }
        return .heading(level, rest.trimmingCharacters(in: .whitespaces))
    }

    private static func bullet(_ raw: String) -> MarkdownBlock? {
        let leading = raw.prefix(while: { $0 == " " || $0 == "\t" }).count
        let t = raw.trimmingCharacters(in: .whitespaces)
        for p in ["- ", "* ", "• ", "+ "] {
            if t.hasPrefix(p) {
                return .bullet(leading / 2, String(t.dropFirst(p.count)))
            }
        }
        return nil
    }

    private static func numbered(_ raw: String) -> MarkdownBlock? {
        let t = raw.trimmingCharacters(in: .whitespaces)
        let digits = t.prefix(while: { $0.isASCII && $0.isNumber })
        if digits.isEmpty || digits.count > 3 { return nil }
        let rest = String(t.dropFirst(digits.count))
        if rest.hasPrefix(". ") || rest.hasPrefix(") ") {
            return .numbered(String(digits) + ".", String(rest.dropFirst(2)))
        }
        return nil
    }
}

struct MarkdownView: View {
    let text: String

    var body: some View {
        let blocks = MarkdownParser.parse(text)
        VStack(alignment: .leading, spacing: 8) {
            ForEach(Array(blocks.enumerated()), id: \.offset) { item in
                blockView(item.element)
            }
        }
    }

    private func headingFont(_ level: Int) -> Font {
        switch level {
        case 1: return .title3.bold()
        case 2: return .headline
        default: return .subheadline.bold()
        }
    }

    @ViewBuilder
    private func blockView(_ b: MarkdownBlock) -> some View {
        switch b {
        case .paragraph(let t):
            Text(markdownText(t))
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
        case .heading(let level, let t):
            Text(markdownText(t))
                .font(headingFont(level))
                .padding(.top, 4)
                .fixedSize(horizontal: false, vertical: true)
        case .bullet(let indent, let t):
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(indent == 0 ? "•" : "◦")
                    .foregroundColor(.secondary)
                Text(markdownText(t))
                    .textSelection(.enabled)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.leading, CGFloat(indent) * 14)
        case .numbered(let n, let t):
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(n)
                    .foregroundColor(.secondary)
                    .monospacedDigit()
                Text(markdownText(t))
                    .textSelection(.enabled)
                    .fixedSize(horizontal: false, vertical: true)
            }
        case .quote(let t):
            Text(markdownText(t))
                .foregroundColor(.secondary)
                .padding(.leading, 12)
                .overlay(alignment: .leading) {
                    Rectangle()
                        .fill(Color.secondary.opacity(0.4))
                        .frame(width: 3)
                }
                .fixedSize(horizontal: false, vertical: true)
        case .code(let lang, let code):
            CodeBlock(language: lang, code: code)
        case .rule:
            Divider()
        }
    }
}

struct CodeBlock: View {
    let language: String
    let code: String
    @State private var copied = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text(language.isEmpty ? "kod" : language)
                    .font(.caption.monospaced())
                    .foregroundColor(.secondary)
                Spacer()
                Button {
                    UIPasteboard.general.string = code
                    Haptics.success()
                    copied = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { copied = false }
                } label: {
                    Label(copied ? "Kopyalandı" : "Kopyala", systemImage: copied ? "checkmark" : "doc.on.doc")
                        .font(.caption)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.primary.opacity(0.08))

            ScrollView(.horizontal, showsIndicators: false) {
                Text(code)
                    .font(.system(.footnote, design: .monospaced))
                    .padding(10)
                    .textSelection(.enabled)
            }
        }
        .background(Color(.tertiarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

// MARK: - Akan cevap balonu (sadece bu parça sık yenilenir)

struct StreamingBubble: View {
    @ObservedObject var live: StreamState
    var onGrow: () -> Void

    var body: some View {
        HStack {
            if live.text.isEmpty {
                HStack(spacing: 10) {
                    TypingDots()
                    if !live.status.isEmpty {
                        Text(live.status)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(Color(.secondarySystemBackground))
                .roundedCorners(18, [.topRight, .bottomLeft, .bottomRight])
            } else {
                VStack(alignment: .leading, spacing: 6) {
                    MarkdownView(text: live.text)
                    if !live.status.isEmpty {
                        Text(live.status)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(Color(.secondarySystemBackground))
                .roundedCorners(18, [.topRight, .bottomLeft, .bottomRight])
            }
            Spacer(minLength: 40)
        }
        .onChange(of: live.text) { _ in onGrow() }
    }
}
