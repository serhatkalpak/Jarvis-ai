import Foundation
import Security
import SwiftUI

enum ProviderType: String, Codable, CaseIterable, Identifiable {
    case openai
    case anthropic

    var id: String { rawValue }
    var label: String {
        switch self {
        case .openai: return "OpenAI uyumlu"
        case .anthropic: return "Anthropic (Claude)"
        }
    }
}

struct ProviderEntry: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var type: ProviderType
    var baseURL: String
    var model: String
    var key: String
    var enabled: Bool
}

// Sohbete eklenen dosya: yazı (txt, pdf, kod...) veya resim
struct Attachment: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var kind: String            // "text" veya "image"
    var text: String? = nil
    var imageBase64: String? = nil
}

struct ChatMessage: Identifiable, Codable, Equatable {
    var id = UUID()
    var role: String            // user, assistant, note, error
    var content: String
    var modelTag: String? = nil
    var attachments: [Attachment]? = nil
}

struct Chat: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var messages: [ChatMessage] = []
    var updated: Date = Date()
    var pinned: Bool? = nil
    var roleID: UUID? = nil
}

struct Role: Identifiable, Codable, Equatable {
    var id = UUID()
    var emoji: String
    var name: String
    var prompt: String
}

struct AppSettings: Codable, Equatable {
    var entries: [ProviderEntry]
    var tavilyKey: String = ""
    var roles: [Role]? = nil
    var theme: String? = nil              // system, light, dark
    var accent: String? = nil             // turuncu, mavi, yesil, mor, pembe
    var customInstructions: String? = nil
    var maxTokens: Int? = nil

    static func defaults() -> AppSettings {
        func e(_ n: String, _ t: ProviderType, _ u: String, _ m: String) -> ProviderEntry {
            return ProviderEntry(name: n, type: t, baseURL: u, model: m, key: "", enabled: true)
        }
        return AppSettings(entries: [
            e("Claude (Anthropic)", .anthropic, "https://api.anthropic.com/v1", "claude-haiku-5-5"),
            e("OpenAI", .openai, "https://api.openai.com/v1", "gpt-4o-mini"),
            e("Gemini (Google)", .openai, "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"),
            e("DeepSeek", .openai, "https://api.deepseek.com", "deepseek-chat"),
            e("OpenRouter (ücretsiz modeller)", .openai, "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free"),
            e("Groq (açık kaynak)", .openai, "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
            e("Mistral", .openai, "https://api.mistral.ai/v1", "mistral-small-latest")
        ])
    }

    // Sabit kimlikler: roller her açılışta aynı kimliği taşısın
    static func defaultRoles() -> [Role] {
        func r(_ n: Int, _ emoji: String, _ name: String, _ prompt: String) -> Role {
            let id = UUID(uuidString: "00000000-0000-0000-0000-00000000000\(n)") ?? UUID()
            return Role(id: id, emoji: emoji, name: name, prompt: prompt)
        }
        return [
            r(1, "💬", "Genel asistan", ""),
            r(2, "🌍", "Çevirmen", "Sen profesyonel bir çevirmensin. Kullanıcının yazdığı metni anlamını bozmadan çevir. Hedef dil belirtilmediyse Türkçe metni İngilizceye, diğer dilleri Türkçeye çevir. Sadece çeviriyi yaz."),
            r(3, "💻", "Kod yardımcısı", "Sen deneyimli bir yazılım mühendisisin. Çalışır kod ver, kısa ve net açıkla. Kullanıcı yeni başlayan olabilir; adım adım anlat."),
            r(4, "✍️", "Yazar ve editör", "Sen bir yazar ve editörsün. Metinleri akıcı, düzgün ve doğal bir dille yaz veya düzelt. Yapılan değişiklikleri kısaca belirt."),
            r(5, "📝", "Özetleyici", "Sen bir özetleme uzmanısın. Verilen metin veya dosyayı önce 3 cümlelik kısa özetle, sonra önemli noktaları madde madde ver."),
            r(6, "🎓", "Öğretmen", "Sen sabırlı bir öğretmensin. Konuyu basit dille, örneklerle ve adım adım anlat. Sonunda anlayıp anlamadığını kontrol edecek kısa bir soru sor.")
        ]
    }
}

func accentColor(_ key: String) -> Color {
    switch key {
    case "mavi": return Color(red: 0.0, green: 0.48, blue: 1.0)
    case "yesil": return Color(red: 0.2, green: 0.68, blue: 0.4)
    case "mor": return Color(red: 0.6, green: 0.35, blue: 0.9)
    case "pembe": return Color(red: 0.95, green: 0.35, blue: 0.6)
    default: return Color(red: 0.79, green: 0.39, blue: 0.26)
    }
}

// API anahtarlarını güvenli saklamak için küçük Keychain yardımcısı
enum Keychain {
    private static let service = "yz.sohbet"

    static func save(_ data: Data, account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var add = base
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(add as CFDictionary, nil)
    }

    static func load(account: String) -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var out: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &out)
        if status == errSecSuccess {
            return out as? Data
        }
        return nil
    }
}
