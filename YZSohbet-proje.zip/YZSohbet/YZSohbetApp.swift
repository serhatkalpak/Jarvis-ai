import SwiftUI

@main
struct YZSohbetApp: App {
    @StateObject private var store = Store()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: Store

    var body: some View {
        TabView(selection: $store.tab) {
            ChatView()
                .tabItem { Label("Sohbet", systemImage: "bubble.left.and.bubble.right") }
                .tag(0)
            HistoryView()
                .tabItem { Label("Geçmiş", systemImage: "clock") }
                .tag(1)
            RolesView()
                .tabItem { Label("Roller", systemImage: "person.2") }
                .tag(2)
            SettingsRootView()
                .tabItem { Label("Ayarlar", systemImage: "gearshape") }
                .tag(3)
        }
        .tint(store.accent)
        .preferredColorScheme(store.colorScheme)
    }
}