import SwiftUI
import UIKit

// MARK: - Titreşim (haptic) yardımcıları

@MainActor
enum Haptics {
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func selection() {
        UISelectionFeedbackGenerator().selectionChanged()
    }

    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

// MARK: - Seçili köşeleri yuvarlayan şekil (mesaj balonları için)

struct RoundedCorner: Shape {
    var radius: CGFloat
    var corners: UIRectCorner

    func path(in rect: CGRect) -> Path {
        let p = UIBezierPath(roundedRect: rect,
                             byRoundingCorners: corners,
                             cornerRadii: CGSize(width: radius, height: radius))
        return Path(p.cgPath)
    }
}

extension View {
    func roundedCorners(_ radius: CGFloat, _ corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

// MARK: - "Yazıyor…" üç nokta animasyonu

struct TypingDots: View {
    @State private var on = false

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .fill(Color.secondary)
                    .frame(width: 7, height: 7)
                    .scaleEffect(on ? 1 : 0.5)
                    .opacity(on ? 1 : 0.35)
                    .animation(.easeInOut(duration: 0.6).repeatForever().delay(Double(i) * 0.2), value: on)
            }
        }
        .onAppear { on = true }
    }
}

// MARK: - Kopyala düğmesi (tıklayınca tik işareti gösterir)

struct CopyButton: View {
    let text: String
    @State private var done = false

    var body: some View {
        Button {
            UIPasteboard.general.string = text
            Haptics.success()
            done = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { done = false }
        } label: {
            Image(systemName: done ? "checkmark" : "doc.on.doc")
        }
        .accessibilityLabel("Kopyala")
    }
}